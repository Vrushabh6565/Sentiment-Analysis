# importing geopy library
import csv
from geopy.geocoders import Nominatim
file = open("Book1.csv")
file2 = open("Book2.csv","w+")
csvreader = csv.reader(file)
row1 = ['GJSD']
count = 0
writer = csv.writer(file2)
for row in csvreader:
	print(count)
	count = count + 1	
	loc = Nominatim(user_agent="GetLoc")
	getLoc = loc.geocode(row[0])
	row.append(getLoc.latitude)
	row.append(getLoc.longitude)
	writer.writerow(row)